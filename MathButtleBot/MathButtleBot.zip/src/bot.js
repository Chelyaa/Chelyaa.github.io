document.addEventListener("keyup", function(e) {
	const code = e.keyCode || e.charCode;
	if(code == 83 && e.altKey) {
		start();
	}
});

function start() {
	recurse(0, 100);

	function recurse(i, n) {
		if (i >= n) return;

		solveCurrTask();

		setTimeout(function() {
			recurse(i+1, n);
		}, 100);
	}
}

function solveCurrTask() {
	const x = +document.getElementById('task_x').innerHTML,
				op = document.getElementById('task_op').innerHTML,
				y = +document.getElementById('task_y').innerHTML,
				res = +document.getElementById('task_res').innerHTML;

	let trueRes = doOperation(x, op, y);
	if (trueRes === res) {
		log(x + ' ' + op + ' ' + y + ' = ' + res + '(true)');
		answer(true);
	} else {
		log(x + ' ' + op + ' ' + y + ' != ' + res + '(false, ' + trueRes + ')');
		answer(false);
	}
}

function doOperation(x, op, y) {
	switch (op) {
		case '+':
			return x + y;
			break;
		case '–':
			return x - y;
			break;
		case '×':
			return x * y;
			break;
		case '/':
			return x / y;
			break;
	}
}

function answer(isCorrect) {
	const buttons = {
		correct: document.getElementById('button_correct'),
		wrong: document.getElementById('button_wrong')
	};

	if (isCorrect) buttons.correct.click();
	else buttons.wrong.click();
}

function log(msg) {
	console.log(msg);
}